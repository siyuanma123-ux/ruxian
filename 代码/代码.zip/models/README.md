# 跨模态乳腺癌诊断模型

## 模块说明

### 1. shared_encoder.py
共享视觉Transformer编码器，支持X光和病理两种模态的统一特征提取。

**主要类：**
- `SharedViTEncoder`: 共享ViT编码器，包含Adapter模块用于保留模态特定特征
- `TransformerBlock`: Transformer编码块
- `AdapterLayer`: 轻量级Adapter，防止模态特征过度混合

### 2. cross_modal_alignment.py
跨模态对齐模块，使用对比学习实现X光和病理特征的语义对齐。

**主要类：**
- `CrossModalAlignment`: 跨模态对齐模块
- `compute_contrastive_loss`: 对比学习损失函数
- `compute_alignment_accuracy`: 对齐准确率评估

### 3. domain_generalization.py
域泛化模块，包含MixStyle和IRM方法。

**主要类：**
- `MixStyle`: 混合不同域的统计特征
- `IRMLoss`: Invariant Risk Minimization损失
- `DomainGeneralization`: 域泛化模块整合

### 4. causal_tta.py
因果测试时自适应，只在推理时更新BN层和Adapter权重。

**主要类：**
- `CausalTTA`: 因果测试时自适应类

### 5. multi_task_heads.py
多任务学习头，包含分类、定位、分级三个任务。

**主要类：**
- `ClassificationHead`: 分类头（四类）
- `LocalizationHead`: 病灶定位头
- `GradingHead`: 病理分级头（序数回归）
- `UncertaintyWeightedMultiTaskLoss`: 不确定性加权多任务损失

### 6. interpretability.py
可解释性模块，通过跨模态注意力生成热图和病理patch关联。

**主要类：**
- `CrossModalAttention`: 跨模态注意力机制
- `InterpretabilityModule`: 可解释性模块

### 7. breast_cancer_model.py
主模型类，整合所有模块。

**主要类：**
- `BreastCancerDiagnosisModel`: 完整的跨模态乳腺癌诊断模型

## 使用方法

```python
from models import BreastCancerDiagnosisModel

# 创建模型
model = BreastCancerDiagnosisModel(
    img_size=224,
    patch_size=16,
    embed_dim=768,
    depth=12,
    num_heads=12
)

# 前向传播
outputs = model(mammo_img, patho_img, return_interpretability=True)

# 输出包含：
# - classification: 分类logits
# - localization: 边界框预测
# - grading: 分级logits
# - heatmap: 热图（如果启用可解释性）
# - top_patho_patches: top-k病理patch（如果启用可解释性）
```

## 训练

使用 `train.py` 脚本进行训练：

```bash
python train.py \
    --mammo_csv path/to/mammo.csv \
    --mammo_root path/to/mammo/images \
    --patho_root path/to/pathology/images \
    --use_pathology \
    --batch_size 16 \
    --epochs 100 \
    --lr 1e-4
```

